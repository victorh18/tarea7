<html>
<head>
	<title>Semaforo</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url();?>js/code.js"></script>

</head>
<body>
	<a id="btnCalleA" href="<?php echo base_url('index.php/App/calleA'); ?>" class="btn btn-primary">Calle A</a>
	<a id="btnCalleB" href="<?php echo base_url('index.php/App/calleB'); ?>" class="btn btn-primary">Calle B</a>
	<a id="btnAdmin" href="<?php echo base_url('index.php/App/Admin'); ?>" class="btn btn-primary">Administracion</a>

</body>

<script type="text/javascript">
	
	
</script>
</html>