<html>
<head>
	<title>Calle B</title>
	<script type="text/javascript" src="<?php echo base_url(); ?>js/code.js"></script>
</head>
<body id="bdCalleB" bgcolor=green onload="intervalCalleB = setInterval(setCalleB, 100);">
	Esta es la calle B

</body>
</html>