<html>
<head>
	<title>Calle A</title>
	<script src="<?php echo base_url();?>js/code.js"></script>
</head>
<body id="bdCalleA" bgcolor=red onload="intervalCalleA = setInterval(setCalleA, 100);">
	Esta es la calle A
	

</body>
</html>